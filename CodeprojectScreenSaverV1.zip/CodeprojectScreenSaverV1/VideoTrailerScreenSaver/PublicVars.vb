﻿Module PublicVars
    Public myoptions As New Options
End Module
