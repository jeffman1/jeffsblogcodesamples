﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmScreenSaver
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmScreenSaver))
        Me.TrailerRotateTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Video = New AxShockwaveFlashObjects.AxShockwaveFlash()
        CType(Me.Video, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TrailerRotateTimer
        '
        '
        'Video
        '
        Me.Video.Enabled = True
        Me.Video.Location = New System.Drawing.Point(0, 4)
        Me.Video.Name = "Video"
        Me.Video.OcxState = CType(resources.GetObject("Video.OcxState"), System.Windows.Forms.AxHost.State)
        Me.Video.Size = New System.Drawing.Size(963, 452)
        Me.Video.TabIndex = 2
        '
        'frmScreenSaver
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(964, 458)
        Me.ControlBox = False
        Me.Controls.Add(Me.Video)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmScreenSaver"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.Video, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Video As AxShockwaveFlashObjects.AxShockwaveFlash
    Friend WithEvents TrailerRotateTimer As System.Windows.Forms.Timer

End Class
