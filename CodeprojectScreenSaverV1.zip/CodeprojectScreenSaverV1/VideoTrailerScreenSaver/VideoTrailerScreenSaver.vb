﻿Public Class VideoTrailerScreenSaver
    Private Enum ActionType
        actConfigure
        actPreview
        actRun
    End Enum

    Public Shared Sub Main(ByVal args As String())
        Dim m_Action As ActionType
        ' See what we should do.
        If args.Length = 0 Then
            m_Action = ActionType.actRun
        Else
            Select Case args(0).ToLower().Substring(0, 2)
                Case "/p"
                    m_Action = ActionType.actPreview
                Case "/c"
                    m_Action = ActionType.actConfigure
                Case "/s"
                    m_Action = ActionType.actRun
                Case Else
                    m_Action = ActionType.actRun
            End Select
        End If

        ' Do it.
        Select Case m_Action
            Case ActionType.actRun
                ' Normal screen saver.
                Dim frmScreenS As New frmScreenSaver
                Application.Run(frmScreenS)
            Case ActionType.actConfigure
                ' Configure.
                Dim dlg_config As New frmOptions
                Application.Run(dlg_config)
            Case ActionType.actPreview
                ' Preview.
                Dim preview As New frmScreenSaver
                Application.Run(preview)
        End Select

     


    End Sub
End Class
