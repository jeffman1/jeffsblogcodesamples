﻿Public Class frmOptions
    Private Sub frmOptions_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        myoptions.LoadOptions()
        If myoptions.VideoGenreSelection <> "" Then
            cboGenre.SelectedIndex = cboGenre.Items.IndexOf(myoptions.VideoGenreSelection)
        Else
            cboGenre.SelectedIndex = 0
        End If
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        myoptions.IsTransparent = False
        If cboGenre.SelectedIndex > -1 Then
            myoptions.TrailerUrlCollection = ProgramServices.RetrieveVideos(cboGenre.Items.Item(cboGenre.SelectedIndex))
            myoptions.VideoGenreSelection = cboGenre.Items.Item(cboGenre.SelectedIndex)
            If IsNumeric(cboPlayTime.Text) Then
                myoptions.TrailerPlayTime = CInt(cboPlayTime.Text)
            End If
            myoptions.SaveOptions()
            Me.Close()
        Else
            MsgBox("need to have a genre selected!")
        End If
    End Sub
End Class