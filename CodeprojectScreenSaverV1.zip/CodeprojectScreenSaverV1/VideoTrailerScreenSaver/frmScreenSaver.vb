﻿Public Class frmScreenSaver
    Private FirstTrailer As Boolean

  

    Private Sub frmScreenSaver_Load(sender As Object, e As EventArgs) Handles Me.Load

        myoptions.LoadOptions()
        'have the first trailers timer be low so it will start playing quicker
        TrailerRotateTimer.Interval = 500
        TrailerRotateTimer.Stop()
        Dim formsize As Size
        formsize.Height = Me.Size.Height
        formsize.Width = Me.Size.Width
        Video.Size = formsize
        Video.AllowFullScreen = True
        Video.Visible = True
        TrailerRotateTimer.Start()
    End Sub

   

    Private Sub TrailerRotateTimer_Tick(sender As Object, e As EventArgs) Handles TrailerRotateTimer.Tick
        If FirstTrailer = False Then
            Select Case myoptions.TrailerPlayTime
                Case Is = 60
                    TrailerRotateTimer.Interval = 60000
                    FirstTrailer = True
                Case Is = 90
                    TrailerRotateTimer.Interval = 90000
                    FirstTrailer = True
                Case Is = 120
                    TrailerRotateTimer.Interval = 120000
                    FirstTrailer = True
                Case Else
                    TrailerRotateTimer.Interval = 60000
                    FirstTrailer = True
            End Select

        End If
        Dim randnum As New Random()
        Dim firstvideo As String = myoptions.TrailerUrlCollection.Item(randnum.Next(0, 5))
        ' Video.Movie = firstvideo
        Video.Stop()
        Video.LoadMovie(0, firstvideo)

        If Video.IsPlaying = False Then
            ' Video.Playing = True
            Video.Play()
            Video.Playing = True
            Video.Loop = False
        End If
    End Sub
    Private Sub frmScreenSaver_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Me.KeyPress
        If e.KeyChar <> "" Then
            Application.Exit()
        End If
    End Sub
    Private Sub Video_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles Video.PreviewKeyDown
        If e.KeyCode = Keys.Escape Then
            Application.Exit()
        End If
    End Sub
End Class

