﻿Imports System.Net
Imports System.Text
Imports System.IO
Public Class ProgramServices

    Public Shared Function RetrieveVideos(genre As String) As List(Of String)
        Dim templst As New List(Of String)
        'retrieve top 4 videos and add them to the list
        Dim url As String = "http://api.traileraddict.com/?actor=" + genre.ToLower + "&count=6"
        Dim req As HttpWebRequest = WebRequest.Create(url)
        Dim resp As HttpWebResponse = req.GetResponse()
        Dim enc As Encoding = System.Text.Encoding.GetEncoding(1252)
        Dim loResponseStream As StreamReader =
        New StreamReader(resp.GetResponseStream(), enc)
        Dim Response As String = loResponseStream.ReadToEnd()
        Dim xmlfile As XDocument = XDocument.Parse(Response)
        Dim videos As IEnumerable(Of XElement) = From t In xmlfile.Descendants("trailers") Select t
        For Each video As XElement In videos
            For Each trailer As XElement In video.Elements("trailer")
                templst.Add("http://v.traileraddict.com/emd/" + trailer.Element("trailer_id").Value + "?id=" + trailer.Element("trailer_id").Value)
            Next
        Next
        loResponseStream.Close()
        resp.Close()

        Return templst
    End Function

End Class
